<div class="row">
  <div class="col-md-12">
    <input type="hidden" name="kode_gejala" value="<?= $gjl->kode_gejala ?>">
    <p>Anda yakin menghapus data <b><?=$gjl->nama_gejala?></b>?</p>
  </div>
</div>