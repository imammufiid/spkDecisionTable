<div class="row">
  <div class="col-md-12">
    <input type="hidden" name="id" value="<?= $condition->id ?>">
    <p>Anda yakin menghapus data <b><?=$condition->condition?></b>?</p>
  </div>
</div>