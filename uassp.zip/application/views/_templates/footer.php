<div class="kt-footer kt-grid__item" id="kt_footer">
	<div class="kt-container">
		<div class="kt-footer__wrapper">
			<div class="kt-footer__copyright">
				<span class="mr-2"><?php echo $_settings->setting_web_name ?></span> <?php echo date('Y') ?>&nbsp;&copy;&nbsp; <span class="ml-1"> support by:</span> <a href="<?php echo $_settings->setting_web_credit_href ?>" target="_blank" class="ml-2 kt-link"><?php echo $_settings->setting_web_credit ?></a>
			</div>
		</div>
	</div>
</div>