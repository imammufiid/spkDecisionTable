<script src="<?= base_url() ?>assets/vendors/general/jquery/dist/jquery.js" type="text/javascript"></script>
<script src="<?= base_url() ?>assets/js/pace.min.js" type="text/javascript"></script>
