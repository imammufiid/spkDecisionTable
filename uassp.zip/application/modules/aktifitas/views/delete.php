<div class="row">
  <div class="col-md-12">
    <input type="hidden" name="id" value="<?= $atlet->id ?>">
    <p>Anda yakin menghapus data <b><?=$atlet->nama_atlet?></b>?</p>
  </div>
</div>